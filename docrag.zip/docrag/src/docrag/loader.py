"""Chargement des documents depuis un dossier (Markdown, texte, PDF)."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

SUPPORTED_SUFFIXES = {".md", ".markdown", ".txt", ".rst", ".pdf"}


@dataclass(frozen=True)
class Document:
    source: str  # chemin relatif au dossier de documents
    text: str


def _read(path: Path) -> str:
    if path.suffix.lower() == ".pdf":
        try:
            from pypdf import PdfReader
        except ImportError as exc:  # pragma: no cover - dépend de l'environnement
            raise RuntimeError(
                "Lecture des PDF impossible : pip install 'docrag[pdf]'"
            ) from exc
        reader = PdfReader(str(path))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)
    return path.read_text(encoding="utf-8", errors="replace")


def load_documents(root: Path | str) -> list[Document]:
    """Charge récursivement tous les fichiers supportés sous `root`."""
    root = Path(root)
    if not root.is_dir():
        raise FileNotFoundError(f"Dossier de documents introuvable : {root}")

    documents: list[Document] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.suffix.lower() not in SUPPORTED_SUFFIXES:
            continue
        text = _read(path)
        if text.strip():
            documents.append(Document(source=path.relative_to(root).as_posix(), text=text))
    return documents
