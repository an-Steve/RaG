"""Configuration centralisée, lue depuis les variables d'environnement / `.env`."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

DEFAULT_BASE_URL = "https://api.mistral.ai/v1"


@dataclass(frozen=True)
class Settings:
    base_url: str = DEFAULT_BASE_URL
    api_key: str = ""
    chat_model: str = "mistral-small-latest"
    embed_model: str = "mistral-embed"
    docs_dir: Path = Path("data/docs")
    index_dir: Path = Path("index")
    chunk_size: int = 900
    chunk_overlap: int = 120
    top_k: int = 4
    min_score: float = 0.0
    temperature: float = 0.2

    @classmethod
    def from_env(cls) -> "Settings":
        load_dotenv()
        env = os.getenv
        return cls(
            base_url=env("LLM_BASE_URL", DEFAULT_BASE_URL).rstrip("/"),
            api_key=env("LLM_API_KEY") or env("MISTRAL_API_KEY", ""),
            chat_model=env("CHAT_MODEL", cls.chat_model),
            embed_model=env("EMBED_MODEL", cls.embed_model),
            docs_dir=Path(env("DOCS_DIR", str(cls.docs_dir))),
            index_dir=Path(env("INDEX_DIR", str(cls.index_dir))),
            chunk_size=int(env("CHUNK_SIZE", cls.chunk_size)),
            chunk_overlap=int(env("CHUNK_OVERLAP", cls.chunk_overlap)),
            top_k=int(env("TOP_K", cls.top_k)),
            min_score=float(env("MIN_SCORE", cls.min_score)),
            temperature=float(env("TEMPERATURE", cls.temperature)),
        )

    @property
    def is_mistral_cloud(self) -> bool:
        return "api.mistral.ai" in self.base_url
