"""docrag — chatbot RAG minimaliste sur documentation technique."""

__version__ = "0.1.0"
