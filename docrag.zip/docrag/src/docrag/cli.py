"""Interface en ligne de commande : `docrag ingest | ask | chat`."""

from __future__ import annotations

import argparse
import dataclasses
import sys
from pathlib import Path
from typing import Sequence

from docrag.config import Settings
from docrag.llm import LLMClient, LLMError
from docrag.pipeline import Hit, IndexMismatchError, RAGPipeline
from docrag.store import IndexNotFoundError


def build_client(settings: Settings) -> LLMClient:
    return LLMClient.from_settings(settings)


def _print_sources(hits: Sequence[Hit]) -> None:
    if not hits:
        return
    print("\nSources :")
    for number, hit in enumerate(hits, start=1):
        heading = f" — {hit.chunk.heading}" if hit.chunk.heading else ""
        print(f"  [{number}] {hit.chunk.source}{heading} (score {hit.score:.2f})")


def _stream_answer(pipeline: RAGPipeline, question: str, history: list[dict]) -> str:
    hits, tokens = pipeline.answer_stream(question, history)
    parts: list[str] = []
    for token in tokens:
        parts.append(token)
        sys.stdout.write(token)
        sys.stdout.flush()
    print()
    _print_sources(hits)
    return "".join(parts)


def _chat_loop(pipeline: RAGPipeline) -> None:
    print("Mode conversation (tape « exit » ou Ctrl-D pour quitter).")
    history: list[dict] = []
    while True:
        try:
            question = input("\nVous > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if not question:
            continue
        if question.lower() in {"exit", "quit", "q", ":q"}:
            return
        print("\nAssistant > ", end="")
        answer = _stream_answer(pipeline, question, history)
        history += [
            {"role": "user", "content": question},
            {"role": "assistant", "content": answer},
        ]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="docrag", description="Chatbot RAG sur documentation technique (Mistral)."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    ingest = sub.add_parser("ingest", help="Indexer les documents du dossier")
    ingest.add_argument("--docs", type=Path, help="Dossier de documents (défaut : DOCS_DIR)")

    ask = sub.add_parser("ask", help="Poser une question unique")
    ask.add_argument("question")
    ask.add_argument("-k", "--top-k", type=int, help="Nombre de passages à récupérer")

    chat = sub.add_parser("chat", help="Discuter avec la documentation")
    chat.add_argument("-k", "--top-k", type=int, help="Nombre de passages à récupérer")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    settings = Settings.from_env()
    if getattr(args, "top_k", None):
        settings = dataclasses.replace(settings, top_k=args.top_k)

    try:
        pipeline = RAGPipeline(build_client(settings), settings)
        if args.command == "ingest":
            n_docs, n_chunks = pipeline.ingest(args.docs)
            print(f"Index créé : {n_docs} document(s), {n_chunks} passage(s) → {settings.index_dir}/")
        elif args.command == "ask":
            _stream_answer(pipeline, args.question, [])
        else:
            _chat_loop(pipeline)
    except (LLMError, IndexNotFoundError, IndexMismatchError, FileNotFoundError, ValueError) as exc:
        print(f"Erreur : {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
