"""Client minimal pour toute API compatible OpenAI (Mistral, Ollama, vLLM, llama.cpp...).

On passe volontairement par HTTP (`requests`) plutôt que par un SDK : les endpoints
`/chat/completions` et `/embeddings` sont identiques chez Mistral et en local, donc
le même code fonctionne pour l'API cloud et pour un modèle auto-hébergé.
"""

from __future__ import annotations

import json
import time
from typing import Iterator, Sequence

import numpy as np
import requests

from docrag.config import Settings

RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class LLMError(RuntimeError):
    """Erreur lors d'un appel au fournisseur de modèles."""


def _content_to_text(content: object) -> str:
    """Certains modèles renvoient une liste de blocs {type, text} au lieu d'une chaîne."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            part.get("text", "") for part in content if isinstance(part, dict)
        )
    return ""


class LLMClient:
    def __init__(
        self,
        base_url: str,
        api_key: str = "",
        chat_model: str = "mistral-small-latest",
        embed_model: str = "mistral-embed",
        temperature: float = 0.2,
        timeout: float = 60.0,
        max_retries: int = 4,
        backoff: float = 1.0,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.chat_model = chat_model
        self.embed_model = embed_model
        self.temperature = temperature
        self.timeout = timeout
        self.max_retries = max_retries
        self.backoff = backoff
        self._session = requests.Session()

    @classmethod
    def from_settings(cls, settings: Settings) -> "LLMClient":
        if settings.is_mistral_cloud and not settings.api_key:
            raise LLMError(
                "MISTRAL_API_KEY manquante. Renseigne-la dans `.env` "
                "ou pointe LLM_BASE_URL vers un serveur local (voir README)."
            )
        return cls(
            base_url=settings.base_url,
            api_key=settings.api_key,
            chat_model=settings.chat_model,
            embed_model=settings.embed_model,
            temperature=settings.temperature,
        )

    # -- HTTP ---------------------------------------------------------------

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _retry_delay(self, response: requests.Response | None, attempt: int) -> float:
        if response is not None:
            try:
                return max(0.0, float(response.headers.get("Retry-After", "")))
            except ValueError:
                pass
        return self.backoff * (2**attempt)

    def _post(self, path: str, payload: dict, stream: bool = False) -> requests.Response:
        url = f"{self.base_url}{path}"
        for attempt in range(self.max_retries + 1):
            last_attempt = attempt == self.max_retries
            try:
                response = self._session.post(
                    url,
                    headers=self._headers(),
                    json=payload,
                    timeout=self.timeout,
                    stream=stream,
                )
            except requests.RequestException as exc:
                if last_attempt:
                    raise LLMError(f"Connexion impossible à {url} : {exc}") from exc
                time.sleep(self._retry_delay(None, attempt))
                continue

            if response.status_code in RETRYABLE_STATUS and not last_attempt:
                delay = self._retry_delay(response, attempt)
                response.close()
                time.sleep(delay)
                continue
            if not response.ok:
                detail = response.text[:300]
                response.close()
                raise LLMError(f"HTTP {response.status_code} sur {path} : {detail}")
            return response
        raise LLMError(f"Échec de l'appel à {url}")  # pragma: no cover

    # -- API ----------------------------------------------------------------

    def embed(self, texts: Sequence[str], batch_size: int = 16) -> np.ndarray:
        """Retourne une matrice (n_textes, dimension) en float32."""
        if not texts:
            return np.zeros((0, 0), dtype=np.float32)
        vectors: list[list[float]] = []
        for start in range(0, len(texts), batch_size):
            batch = list(texts[start : start + batch_size])
            data = self._post(
                "/embeddings", {"model": self.embed_model, "input": batch}
            ).json()
            items = sorted(data["data"], key=lambda item: item["index"])
            if len(items) != len(batch):
                raise LLMError("Nombre d'embeddings renvoyés inattendu")
            vectors.extend(item["embedding"] for item in items)
        return np.asarray(vectors, dtype=np.float32)

    def _chat_payload(self, messages: list[dict], stream: bool) -> dict:
        payload = {
            "model": self.chat_model,
            "messages": messages,
            "temperature": self.temperature,
        }
        if stream:
            payload["stream"] = True
        return payload

    def chat(self, messages: list[dict]) -> str:
        data = self._post("/chat/completions", self._chat_payload(messages, False)).json()
        return _content_to_text(data["choices"][0]["message"]["content"])

    def chat_stream(self, messages: list[dict]) -> Iterator[str]:
        """Génère la réponse au fil de l'eau (Server-Sent Events)."""
        response = self._post("/chat/completions", self._chat_payload(messages, True), stream=True)
        response.encoding = "utf-8"
        with response:
            for line in response.iter_lines(decode_unicode=True):
                if not line or not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if data == "[DONE]":
                    break
                try:
                    choices = json.loads(data).get("choices") or []
                except json.JSONDecodeError:
                    continue
                if not choices:
                    continue
                delta = _content_to_text((choices[0].get("delta") or {}).get("content"))
                if delta:
                    yield delta
