"""Découpage des documents en passages (« chunks ») pour l'indexation.

Stratégie :
1. On découpe d'abord par sections Markdown, en gardant le « fil d'Ariane » des
   titres (ex. « Architecture > Bascule automatique ») comme contexte.
2. Dans chaque section, on regroupe des paragraphes entiers jusqu'à `size` caractères.
   Les blocs de code (```) ne sont jamais coupés en plein milieu d'un paragraphe.
3. Un paragraphe plus long que `size` est découpé en fenêtres qui se chevauchent
   de `overlap` caractères.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from docrag.loader import Document

_HEADING = re.compile(r"^(#{1,6})\s+(.*\S)\s*$")


@dataclass(frozen=True)
class Chunk:
    source: str
    heading: str
    text: str

    def embed_text(self) -> str:
        """Texte envoyé au modèle d'embedding : le titre aide la recherche."""
        return f"{self.heading}\n\n{self.text}" if self.heading else self.text


def _is_fence(line: str) -> bool:
    return line.lstrip().startswith("```")


def _sections(text: str) -> list[tuple[str, str]]:
    """Retourne des couples (fil d'Ariane des titres, corps de la section)."""
    stack: list[tuple[int, str]] = []
    sections: list[tuple[str, str]] = []
    buffer: list[str] = []
    in_fence = False

    def flush() -> None:
        body = "\n".join(buffer).strip()
        if body:
            sections.append((" > ".join(title for _, title in stack), body))
        buffer.clear()

    for line in text.splitlines():
        if _is_fence(line):
            in_fence = not in_fence
        match = None if in_fence else _HEADING.match(line)
        if match:
            flush()
            level = len(match.group(1))
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, match.group(2)))
        else:
            buffer.append(line)
    flush()
    return sections


def _paragraphs(body: str) -> list[str]:
    paragraphs: list[str] = []
    current: list[str] = []
    in_fence = False
    for line in body.splitlines():
        if _is_fence(line):
            in_fence = not in_fence
        if not line.strip() and not in_fence:
            if current:
                paragraphs.append("\n".join(current))
                current = []
        else:
            current.append(line)
    if current:
        paragraphs.append("\n".join(current))
    return paragraphs


def _split_long(text: str, size: int, overlap: int) -> list[str]:
    """Découpe un long paragraphe en fenêtres chevauchantes, coupées sur un espace."""
    pieces: list[str] = []
    start = 0
    while start < len(text):
        end = min(start + size, len(text))
        if end < len(text):
            cut = text.rfind(" ", start + size // 2, end)
            if cut != -1:
                end = cut
        piece = text[start:end].strip()
        if piece:
            pieces.append(piece)
        if end >= len(text):
            break
        next_start = max(end - overlap, start + 1)
        if not text[next_start - 1].isspace():
            # ne pas commencer une fenêtre au milieu d'un mot
            space = text.find(" ", next_start, end + 1)
            if space != -1:
                next_start = space + 1
        start = next_start
    return pieces


def chunk_document(doc: Document, size: int = 900, overlap: int = 120) -> list[Chunk]:
    if size <= 0:
        raise ValueError("size doit être > 0")
    if not 0 <= overlap < size:
        raise ValueError("overlap doit être compris entre 0 et size-1")

    chunks: list[Chunk] = []
    for heading, body in _sections(doc.text):
        current = ""
        for paragraph in _paragraphs(body):
            units = [paragraph] if len(paragraph) <= size else _split_long(paragraph, size, overlap)
            for unit in units:
                if current and len(current) + 2 + len(unit) > size:
                    chunks.append(Chunk(doc.source, heading, current))
                    current = unit
                else:
                    current = f"{current}\n\n{unit}" if current else unit
        if current:
            chunks.append(Chunk(doc.source, heading, current))
    return chunks
