"""Magasin de vecteurs minimal : matrice numpy + métadonnées JSON.

Pour quelques milliers de passages, un produit scalaire numpy est largement assez
rapide ; inutile d'introduire une base vectorielle. Les vecteurs sont normalisés à
la construction, donc le produit scalaire équivaut à la similarité cosinus.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

import numpy as np

from docrag.chunker import Chunk

VECTORS_FILE = "vectors.npy"
CHUNKS_FILE = "chunks.json"


class IndexNotFoundError(RuntimeError):
    """L'index n'existe pas encore : lancer `docrag ingest`."""


def _normalize(matrix: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(matrix, axis=-1, keepdims=True)
    norms[norms == 0] = 1.0
    return matrix / norms


class VectorStore:
    def __init__(self, vectors: np.ndarray, chunks: list[Chunk], meta: dict | None = None):
        if len(vectors) != len(chunks):
            raise ValueError("Autant de vecteurs que de chunks sont attendus")
        self.vectors = _normalize(np.asarray(vectors, dtype=np.float32))
        self.chunks = chunks
        self.meta = dict(meta or {})

    def __len__(self) -> int:
        return len(self.chunks)

    def search(self, query: np.ndarray, k: int = 4) -> list[tuple[Chunk, float]]:
        """Retourne les `k` chunks les plus proches, avec leur score cosinus."""
        if len(self) == 0:
            return []
        query = _normalize(np.asarray(query, dtype=np.float32).reshape(1, -1))[0]
        if query.shape[0] != self.vectors.shape[1]:
            raise ValueError(
                f"Dimension de la requête ({query.shape[0]}) différente de celle de "
                f"l'index ({self.vectors.shape[1]}) : réindexe avec le même modèle."
            )
        scores = self.vectors @ query
        top = np.argsort(-scores)[: max(k, 0)]
        return [(self.chunks[i], float(scores[i])) for i in top]

    def save(self, directory: Path | str) -> None:
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        np.save(directory / VECTORS_FILE, self.vectors)
        payload = {"meta": self.meta, "chunks": [asdict(c) for c in self.chunks]}
        (directory / CHUNKS_FILE).write_text(
            json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8"
        )

    @classmethod
    def load(cls, directory: Path | str) -> "VectorStore":
        directory = Path(directory)
        vectors_path, chunks_path = directory / VECTORS_FILE, directory / CHUNKS_FILE
        if not vectors_path.exists() or not chunks_path.exists():
            raise IndexNotFoundError(
                f"Aucun index dans « {directory} ». Lance d'abord : docrag ingest"
            )
        payload = json.loads(chunks_path.read_text(encoding="utf-8"))
        chunks = [Chunk(**c) for c in payload["chunks"]]
        return cls(np.load(vectors_path), chunks, payload.get("meta", {}))
