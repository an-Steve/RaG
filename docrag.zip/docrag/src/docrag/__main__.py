from docrag.cli import main

raise SystemExit(main())
