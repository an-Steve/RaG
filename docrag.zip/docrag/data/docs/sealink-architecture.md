# SeaLink — Architecture du système de communications

> Document **fictif**, fourni uniquement pour démontrer le chatbot RAG.
> Remplace-le par ta propre documentation technique.

## Vue d'ensemble

SeaLink est un système de communications embarqué (fictif) qui fournit de la connectivité
à un navire. Il agrège trois liaisons : une liaison satellite VSAT en bande Ku (liaison
principale), une liaison 4G/5G côtière (secours) et une liaison HF (dernier recours).
Une passerelle de routage unique, le service `sl-gateway`, choisit la liaison à utiliser
et applique les règles de qualité de service.

## Liaisons disponibles

### VSAT bande Ku

Liaison utilisée par défaut. Débit nominal de 20 Mb/s en descendant et 5 Mb/s en montant.
La latence typique est d'environ 650 ms, ce qui est normal pour une liaison géostationnaire.

### 4G/5G côtière

Disponible à moins de 20 milles nautiques des côtes environ. Débit jusqu'à 50 Mb/s et
latence d'environ 60 ms. C'est la liaison de secours prioritaire lorsque la VSAT est dégradée.

### HF

Liaison de dernier recours, avec un débit de 2,4 kb/s seulement. Elle n'achemine que la
classe de trafic C0 (messages critiques au format texte).

## Qualité de service (QoS)

Le trafic est réparti en quatre classes, par ordre de priorité décroissant :

| Classe | Usage                                        | Débit garanti |
|--------|----------------------------------------------|---------------|
| C0     | Messages critiques (alertes, positions)      | 64 kb/s       |
| C1     | Voix sur IP                                  | 128 kb/s      |
| C2     | Données opérationnelles (télémaintenance)    | 512 kb/s      |
| C3     | Best-effort (accès Internet de l'équipage)   | aucun         |

La classe C0 préempte toutes les autres : en cas de saturation, C3 est la première dégradée.

## Bascule automatique

La passerelle mesure toutes les 2 secondes le taux de perte de paquets et la latence de
chaque liaison. Elle bascule de la VSAT vers la 4G si le taux de perte dépasse 5 % pendant
8 secondes consécutives, ou si le signal satellite est absent.

Le retour vers la VSAT n'a lieu qu'après 120 secondes de stabilité (hystérésis), afin
d'éviter les allers-retours répétés entre liaisons. Chaque bascule est journalisée avec
l'événement `LINK_SWITCH`. Les sessions TCP existantes sont maintenues grâce à un tunnel
entre la passerelle et le centre de service à terre.

## Supervision

Les métriques sont exposées au format Prometheus sur le port 9100, chemin `/metrics`.
Les principales sont `sl_link_up`, `sl_link_latency_ms`, `sl_link_loss_ratio` et
`sl_qos_queue_depth`.

Les journaux sont écrits en JSON dans `/var/log/sealink/gateway.log`, avec une rotation
quotidienne et une conservation de 30 jours.
