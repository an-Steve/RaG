import numpy as np
import pytest

from docrag.chunker import Chunk
from docrag.store import IndexNotFoundError, VectorStore


def make_store() -> VectorStore:
    chunks = [Chunk("a.md", "A", "alpha"), Chunk("b.md", "B", "beta"), Chunk("c.md", "", "gamma")]
    vectors = np.array([[1, 0, 0], [0, 2, 0], [0, 0, 3]], dtype=np.float32)
    return VectorStore(vectors, chunks, {"embed_model": "m"})


def test_search_returns_best_first_with_cosine_scores():
    store = make_store()
    hits = store.search(np.array([0.1, 5.0, 0.0]), k=2)
    assert [c.source for c, _ in hits] == ["b.md", "a.md"]
    assert hits[0][1] == pytest.approx(1.0, abs=1e-3)
    assert hits[0][1] > hits[1][1]


def test_search_rejects_wrong_dimension():
    with pytest.raises(ValueError, match="Dimension"):
        make_store().search(np.array([1.0, 0.0]), k=1)


def test_save_and_load_roundtrip(tmp_path):
    store = make_store()
    store.save(tmp_path)
    loaded = VectorStore.load(tmp_path)
    assert loaded.chunks == store.chunks
    assert loaded.meta == {"embed_model": "m"}
    assert np.allclose(loaded.vectors, store.vectors)


def test_load_missing_index(tmp_path):
    with pytest.raises(IndexNotFoundError):
        VectorStore.load(tmp_path / "nope")


def test_mismatched_lengths():
    with pytest.raises(ValueError):
        VectorStore(np.zeros((2, 3)), [Chunk("a", "", "x")])
