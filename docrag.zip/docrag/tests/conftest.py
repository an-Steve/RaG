from __future__ import annotations

import re
import zlib
from pathlib import Path

import numpy as np
import pytest

from docrag.config import Settings

SAMPLE_DOCS = Path(__file__).resolve().parents[1] / "data" / "docs"


class FakeClient:
    """Faux client : embeddings « sac de mots » déterministes + réponses enregistrées."""

    embed_model = "fake-embed"

    def __init__(self, dim: int = 512) -> None:
        self.dim = dim
        self.chat_calls: list[list[dict]] = []
        self.reply = "Réponse de test [1]."

    def embed(self, texts):
        matrix = np.zeros((len(texts), self.dim), dtype=np.float32)
        for row, text in enumerate(texts):
            for word in re.findall(r"\w+", text.lower()):
                matrix[row, zlib.crc32(word.encode()) % self.dim] += 1.0
        return matrix

    def chat(self, messages):
        self.chat_calls.append(messages)
        return self.reply

    def chat_stream(self, messages):
        self.chat_calls.append(messages)
        yield from (self.reply[i : i + 5] for i in range(0, len(self.reply), 5))


@pytest.fixture
def fake_client() -> FakeClient:
    return FakeClient()


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        docs_dir=SAMPLE_DOCS,
        index_dir=tmp_path / "index",
        chunk_size=600,
        chunk_overlap=80,
        top_k=3,
    )
