"""Teste le client HTTP contre un faux serveur compatible OpenAI (aucun réseau externe)."""

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

import pytest

from docrag.llm import LLMClient, LLMError


class Handler(BaseHTTPRequestHandler):
    calls: list = []
    failures_before_success = 0
    always_status = None

    def log_message(self, *args):  # silence
        pass

    def _send_json(self, status, body):
        raw = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        type(self).calls.append((self.path, self.headers.get("Authorization"), body))

        if type(self).always_status:
            return self._send_json(type(self).always_status, {"error": "boom"})
        if type(self).failures_before_success > 0:
            type(self).failures_before_success -= 1
            return self._send_json(429, {"error": "rate limited"})

        if self.path == "/v1/embeddings":
            data = [
                {"index": i, "embedding": [float(len(text)), 1.0]}
                for i, text in enumerate(body["input"])
            ]
            return self._send_json(200, {"data": list(reversed(data))})  # ordre volontairement inversé

        if self.path == "/v1/chat/completions" and body.get("stream"):
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            for piece in ["Bon", "jour ", "é", "té"]:
                event = {"choices": [{"delta": {"content": piece}}]}
                self.wfile.write(f"data: {json.dumps(event, ensure_ascii=False)}\n\n".encode())
            self.wfile.write(b'data: {"choices": []}\n\ndata: [DONE]\n\n')
            return

        if self.path == "/v1/chat/completions":
            content = [{"type": "text", "text": "Salut"}, {"type": "text", "text": " !"}]
            return self._send_json(200, {"choices": [{"message": {"content": content}}]})

        self._send_json(404, {"error": "not found"})


@pytest.fixture
def client():
    Handler.calls, Handler.failures_before_success, Handler.always_status = [], 0, None
    server = HTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield LLMClient(
        base_url=f"http://127.0.0.1:{server.server_port}/v1",
        api_key="secret",
        backoff=0.0,
        max_retries=2,
    )
    server.shutdown()


def test_embed_batches_and_restores_order(client):
    texts = ["a", "bb", "ccc", "dddd", "eeeee"]
    matrix = client.embed(texts, batch_size=2)
    assert matrix.shape == (5, 2)
    assert matrix[:, 0].tolist() == [1.0, 2.0, 3.0, 4.0, 5.0]
    assert len([c for c in Handler.calls if c[0] == "/v1/embeddings"]) == 3


def test_sends_bearer_token_and_model(client):
    client.embed(["x"])
    path, auth, body = Handler.calls[0]
    assert auth == "Bearer secret" and body["model"] == "mistral-embed"


def test_chat_handles_list_content(client):
    assert client.chat([{"role": "user", "content": "hi"}]) == "Salut !"


def test_chat_stream_yields_deltas_and_decodes_utf8(client):
    pieces = list(client.chat_stream([{"role": "user", "content": "hi"}]))
    assert "".join(pieces) == "Bonjour été"


def test_retries_on_rate_limit(client):
    Handler.failures_before_success = 2
    assert client.embed(["x"]).shape == (1, 2)
    assert len(Handler.calls) == 3


def test_gives_up_after_max_retries(client):
    Handler.failures_before_success = 99
    with pytest.raises(LLMError, match="429"):
        client.embed(["x"])


def test_non_retryable_error_is_raised_immediately(client):
    Handler.always_status = 401
    with pytest.raises(LLMError, match="401"):
        client.chat([{"role": "user", "content": "hi"}])
    assert len(Handler.calls) == 1


def test_connection_error_is_wrapped():
    dead = LLMClient(base_url="http://127.0.0.1:9/v1", backoff=0.0, max_retries=1, timeout=1)
    with pytest.raises(LLMError, match="Connexion impossible"):
        dead.embed(["x"])
