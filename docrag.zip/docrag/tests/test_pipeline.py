import dataclasses

import pytest

from docrag.pipeline import (
    NO_HIT_MESSAGE,
    IndexMismatchError,
    RAGPipeline,
    format_context,
)
from docrag.store import IndexNotFoundError


@pytest.fixture
def pipeline(fake_client, settings):
    pipe = RAGPipeline(fake_client, settings)
    pipe.ingest()
    return pipe


def test_ingest_builds_and_persists_index(fake_client, settings):
    n_docs, n_chunks = RAGPipeline(fake_client, settings).ingest()
    assert n_docs == 2 and n_chunks >= 6
    assert (settings.index_dir / "vectors.npy").exists()
    assert (settings.index_dir / "chunks.json").exists()


def test_retrieves_the_right_passage(pipeline):
    hits = pipeline.retrieve("Que signifie le code erreur E-214 ?")
    assert hits[0].chunk.source == "sealink-exploitation.md"
    assert "E-214" in hits[0].chunk.text


def test_answer_puts_context_in_prompt(pipeline, fake_client):
    answer = pipeline.answer("Sur quel port sont exposées les métriques Prometheus ?")
    assert answer.text == fake_client.reply
    system, user = fake_client.chat_calls[-1]
    assert system["role"] == "system" and "UNIQUEMENT" in system["content"]
    assert "<contexte>" in user["content"] and "9100" in user["content"]
    assert user["content"].rstrip().endswith("Prometheus ?")


def test_followup_question_is_rewritten_using_history(pipeline, fake_client):
    fake_client.reply = "délai de bascule automatique vers la 4G"
    history = [
        {"role": "user", "content": "Comment fonctionne la bascule ?"},
        {"role": "assistant", "content": "Elle passe de la VSAT à la 4G."},
    ]
    hits = pipeline.retrieve("Et le retour ?", history)
    condense_prompt = fake_client.chat_calls[0][0]["content"]
    assert "Et le retour ?" in condense_prompt and "Comment fonctionne la bascule" in condense_prompt
    assert hits  # la recherche a utilisé la question réécrite


def test_history_is_passed_to_the_model_without_context(pipeline, fake_client):
    fake_client.reply = "question réécrite sur la bascule"
    history = [
        {"role": "user", "content": "Parle-moi de la bascule."},
        {"role": "assistant", "content": "D'accord."},
    ]
    pipeline.answer("Et le retour ?", history)
    messages = fake_client.chat_calls[-1]
    assert [m["role"] for m in messages] == ["system", "user", "assistant", "user"]
    assert "<contexte>" not in messages[1]["content"]


def test_stream_returns_hits_then_tokens(pipeline, fake_client):
    hits, tokens = pipeline.answer_stream("Quel est le débit de la liaison HF ?")
    assert hits
    assert "".join(tokens) == fake_client.reply


def test_min_score_filters_everything_without_calling_the_model(fake_client, settings):
    strict = dataclasses.replace(settings, min_score=0.99)
    pipe = RAGPipeline(fake_client, strict)
    pipe.ingest()
    answer = pipe.answer("recette de la ratatouille")
    assert answer.text == NO_HIT_MESSAGE and answer.hits == []
    assert fake_client.chat_calls == []


def test_missing_index_gives_clear_error(fake_client, settings):
    with pytest.raises(IndexNotFoundError):
        RAGPipeline(fake_client, settings).retrieve("bonjour")


def test_index_built_with_other_model_is_rejected(fake_client, settings):
    RAGPipeline(fake_client, settings).ingest()
    other = type(fake_client)()
    other.embed_model = "autre-modele"
    with pytest.raises(IndexMismatchError):
        RAGPipeline(other, settings).retrieve("bonjour")


def test_ingest_without_documents(fake_client, settings, tmp_path):
    empty = tmp_path / "vide"
    empty.mkdir()
    with pytest.raises(ValueError):
        RAGPipeline(fake_client, settings).ingest(empty)


def test_format_context_numbers_sources(pipeline):
    hits = pipeline.retrieve("codes d'erreur")
    context = format_context(hits)
    assert context.startswith("[1] ") and "\n\n---\n\n[2] " in context
