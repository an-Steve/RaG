import pytest

from docrag.chunker import chunk_document
from docrag.loader import Document


def make(text: str) -> Document:
    return Document("doc.md", text)


def test_keeps_heading_path():
    doc = make("# A\n\nintro\n\n## B\n\ncorps de B\n\n### C\n\ncorps de C")
    chunks = chunk_document(doc, size=200, overlap=20)
    assert [c.heading for c in chunks] == ["A", "A > B", "A > B > C"]
    assert chunks[2].text == "corps de C"


def test_heading_level_resets_path():
    doc = make("# A\n\n## B\n\nx\n\n## C\n\ny")
    assert [c.heading for c in chunk_document(doc, 200, 20)] == ["A > B", "A > C"]


def test_packs_small_paragraphs_together():
    doc = make("# T\n\n" + "\n\n".join(f"para {i}" for i in range(5)))
    chunks = chunk_document(doc, size=500, overlap=50)
    assert len(chunks) == 1
    assert "para 0" in chunks[0].text and "para 4" in chunks[0].text


def test_respects_max_size_and_overlaps_long_paragraphs():
    words = [f"mot{i}" for i in range(400)]
    chunks = chunk_document(make("# T\n\n" + " ".join(words)), size=300, overlap=60)
    assert len(chunks) > 3
    assert all(len(c.text) <= 300 for c in chunks)
    # chevauchement : le dernier mot d'un chunk réapparaît au début du suivant
    assert chunks[0].text.split()[-1] in chunks[1].text.split()[:15]
    # aucun mot n'est perdu
    seen = {w for c in chunks for w in c.text.split()}
    assert seen == set(words)


def test_code_fence_is_not_split_on_blank_lines():
    doc = make("# T\n\n```bash\nls\n\nls -l\n```")
    (chunk,) = chunk_document(doc, size=200, overlap=20)
    assert "ls\n\nls -l" in chunk.text


def test_hash_inside_code_fence_is_not_a_heading():
    doc = make("# T\n\n```bash\n# un commentaire\necho ok\n```")
    (chunk,) = chunk_document(doc, size=200, overlap=20)
    assert chunk.heading == "T"
    assert "# un commentaire" in chunk.text


def test_text_without_headings():
    (chunk,) = chunk_document(make("juste du texte"), 200, 20)
    assert chunk.heading == ""
    assert chunk.embed_text() == "juste du texte"


@pytest.mark.parametrize("size,overlap", [(0, 0), (100, 100), (100, -1)])
def test_invalid_parameters(size, overlap):
    with pytest.raises(ValueError):
        chunk_document(make("x"), size, overlap)
