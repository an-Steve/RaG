import pytest

from docrag import cli
from docrag.config import Settings


@pytest.fixture
def wired(monkeypatch, fake_client, settings):
    monkeypatch.setattr(cli.Settings, "from_env", classmethod(lambda cls: settings))
    monkeypatch.setattr(cli, "build_client", lambda s: fake_client)
    return settings


def test_ingest_then_ask(wired, capsys):
    assert cli.main(["ingest"]) == 0
    assert "Index créé" in capsys.readouterr().out

    assert cli.main(["ask", "Que signifie le code erreur E-214 ?", "-k", "2"]) == 0
    out = capsys.readouterr().out
    assert "Réponse de test [1]." in out
    assert "Sources :" in out and "sealink-exploitation.md" in out


def test_ask_without_index_returns_error(wired, capsys):
    assert cli.main(["ask", "bonjour"]) == 1
    assert "docrag ingest" in capsys.readouterr().err


def test_missing_api_key_message(monkeypatch, capsys):
    monkeypatch.setattr(cli.Settings, "from_env", classmethod(lambda cls: Settings()))
    assert cli.main(["ingest"]) == 1
    assert "MISTRAL_API_KEY" in capsys.readouterr().err
